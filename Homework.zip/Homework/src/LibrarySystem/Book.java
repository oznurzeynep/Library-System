package LibrarySystem;

import java.util.Date;

public class Book {
	
	private String bookName;
	private String authorName;
	private Date insertedDate;
	private Boolean bookInLibrary;
	private Date borrowedDate;
	private String lastBorrowedStudentNumber;
	private Date willReturnDate;
	
	
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Date getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}
	public Date getBorrowedDate() {
		return borrowedDate;
	}
	public void setBorrowedDate(Date borrowedDate) {
		this.borrowedDate = borrowedDate;
	}
	public String getLastBorrowedStudentNumber() {
		return lastBorrowedStudentNumber;
	}
	public void setLastBorrowedStudentNumber(String lastBorrowedStudentNumber) {
		this.lastBorrowedStudentNumber = lastBorrowedStudentNumber;
	}
	public Date getWillReturnDate() {
		return willReturnDate;
	}
	public void setWillReturnDate(Date willReturnDate) {
		this.willReturnDate = willReturnDate;
	}
	public Boolean getBookInLibrary() {
		return bookInLibrary;
	}
	public void setBookInLibrary(Boolean bookInLibrary) {
		this.bookInLibrary = bookInLibrary;
	}
}
