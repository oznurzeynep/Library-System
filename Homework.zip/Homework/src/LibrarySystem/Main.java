package LibrarySystem;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {

	
	static DateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
	static String studentFile = "Students.txt";
	static String bookFile = "Books.txt";
	static List<Student> studentList = new ArrayList<Student>();
	static List<Book> bookList = new ArrayList<Book>();

	public static void main(String[] args) throws ParseException {
		
		
		readStudentsFile();
		readBookFile();
		showInitials();

	}
	
	public static void showInitials() throws ParseException {
		System.out.println(
				"0)Exit" + "\n" 
		      + "1)Insert new book " + "\n" 
		      + "2)Insert new student" + "\n" 
		      + "3)Reserved Book" + "\n"
			  + "4)Unreserved Book" + "\n" 
		      + "5)Overdue Book List" + "\n" 
			  + "Enter an number for operation:");

		int x = getIntFromUser();

		switch (x) {
		case 0:
			System.out.println("\n" + "GOOD BYE!!!!" + "\n");
			break;
		case 1:
			insertNewBook();
			System.out.println("Successfully book inserted!!!");
			showInitials();
			break;
		case 2:
			insertNewStudent();
			System.out.println("Successfully student inserted!!!");
			showInitials();
			break;
		case 3:
			listBooks();
			System.out.println("\n" + "Enter your student number:");
			String studentNumber = getDataFromUser();
			if(!controlStudentNumber(studentNumber)) {
				System.out.println("\n" + "This student doesn't registered!!!!");
				System.out.println("\n" + "1) Register student");
				System.out.println("\n" + "2) Exit");
				int choiceForStudentRegister = getIntFromUser();
				if(choiceForStudentRegister == 1) {
					insertNewStudent();
					showInitials();
				}else if(choiceForStudentRegister == 2) {
					System.out.println("\n" + "GOOD BYE!!!!" + "\n");
					break;
				}else {
					System.out.println("\n" + "You entered wrong operation number!!!!" + "\n");
					showInitials();
				}
				
			}else {
				System.out.println("\n" + "Enter want to reserved book name:");
				String selectedBook = getDataFromUser();
				System.out.println("\n" + "Enter when will you give book back? (Format:dd.MM.yyyy):");
				String giveBackDate = getDataFromUser();
				reserveBook(selectedBook, studentNumber, giveBackDate);
				showInitials();
			}

			break;
		case 4:
			System.out.println("\n" + "Enter your student number:");
			String studentNumber2 = getDataFromUser();
			if(!controlStudentNumber(studentNumber2)) {
				System.out.println("\n" + "This student doesn't registered!!!!");
				showInitials();
			}
			if(studentsBorrowedBooks(studentNumber2)) {
				System.out.println("\n" + "Enter want to unreserved book name:");
				String selectedBook2 = getDataFromUser();
				unreserveBook(selectedBook2, studentNumber2);
			}
			showInitials();
			break;
		case 5:
			showOverdueBooks();
			showInitials();
			break;
		default:
			System.out.println("\n" + "You entered wrong operation number!!!!" + "\n");
			showInitials();
		}
	}

	public static void insertNewStudent() throws ParseException {
		Student student = new Student();
		System.out.println("\n" + "Enter student number:" + "\n");
		student.setStudentNumber(getDataFromUser());
		if(!controlStudent(student.getStudentNumber())) {
			System.out.println("\n" + "This students has already recorded!!!" + "\n");
			showInitials();
			return;
		}
		System.out.println("Enter student name:" + "\n");
		student.setStudentName(getDataFromUser());
		student.setRegisteredDate(new Date());
		
		writeFile("insertStudent",createInsertStudentLineForText(student));
		studentList.add(student);
		
	}
	
	public static boolean controlStudent(String studentNumber) {
		for(Student s : studentList) {
			if(s.getStudentNumber().equals(studentNumber)) {
				return false;
			}
		}
		return true;
	}
	
	public static boolean controlBook(String bookName) {
		for(Book s : bookList) {
			if(s.getBookName().equals(bookName)) {
				return false;
			}
		}
		return true;
	}

	public static void insertNewBook() throws ParseException {
		Book book = new Book();
		System.out.println("\n" + "Enter book name:" + "\n");
		
		String bookName = getDataFromUser();
		book.setBookName(bookName);
		if(!controlBook(book.getBookName())) {
			System.out.println("\n" + "This book has already recorded!!!" + "\n");
			showInitials();
			return;
		}
		System.out.println("\n" + "Enter author name:" + "\n");
		String authorName = getDataFromUser();
		book.setAuthorName(authorName);
		book.setInsertedDate(new Date());
		book.setBookInLibrary(Boolean.TRUE);
		
		writeFile("insertBook",createInsertBookLineForText(book));
		bookList.add(book);
	}


	public Book getBookDetails(String bookName) {
		Book book = new Book();

		return book;
	}

	public static void writeFile(String operation, String fileLine) {
		if (operation.equals("insertBook")) {
			try {
				File myObj = new File(bookFile);
				myObj.createNewFile();

				Writer output;
				output = new BufferedWriter(new FileWriter(bookFile, true));
				output.append(fileLine + "\n");
				output.close();
			} catch (IOException e) {
				System.out.println("An error occurred.");
				e.printStackTrace();
			}
		}else if(operation.equals("insertStudent")) {
			try {
				File myObj = new File(studentFile);
				myObj.createNewFile();
				Writer output;
				output = new BufferedWriter(new FileWriter(studentFile, true));
				output.append(fileLine + "\n");
				output.close();
				

			} catch (IOException e) {
				System.out.println("An error occurred.");
				e.printStackTrace();
			}
		}
	}
	
	public static void readStudentsFile() {
	    try {
	    	
	        File myObj = new File(studentFile);
			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
			}
	        Scanner myReader = new Scanner(myObj);
	        while (myReader.hasNextLine()) {
	          String data = myReader.nextLine();
	          if(data.length() != 0) {
		          String[] studentData = data.split(";");
		          Student student = new Student();
		          student.setStudentNumber(studentData[0]);
		          student.setStudentName(studentData[1]);
		          student.setRegisteredDate(formatter.parse(studentData[2]));
		          studentList.add(student);
	          }

	        }
	        myReader.close();
	      } catch (ParseException | IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      }
	}
	
	public static void readBookFile(){
	    try {
	    	
	        File myObj = new File(bookFile);
			if (myObj.createNewFile()) {
				System.out.println("File created: " + myObj.getName());
			}
	        Scanner myReader = new Scanner(myObj);
	        while (myReader.hasNextLine()) {
	          String data = myReader.nextLine();
	          if(data.length() != 0) {
		          String[] bookData = data.split(";");
		          Book book = new Book();
		          book.setBookName(bookData[0]);
		          book.setAuthorName(bookData[1]);
		          book.setInsertedDate(formatter.parse(bookData[2]));
		          if(bookData[3].equals("YES")) {
		        	  book.setBookInLibrary(Boolean.TRUE);
		          }else {
		        	  book.setBookInLibrary(Boolean.FALSE);
		          }
		          if(bookData.length>=5 && !bookData[4].isEmpty()) {
		        	  book.setBorrowedDate(formatter.parse(bookData[4]));
		          }
		          if(bookData.length>=6 && !bookData[5].isEmpty()) {
		        	  book.setLastBorrowedStudentNumber(bookData[5]);
		          }
		          if(bookData.length>=7 && !bookData[6].isEmpty()) {
		        	  book.setWillReturnDate(formatter.parse(bookData[6]));
		          }
		          bookList.add(book);
	          }

	        }
	        myReader.close();
	      } catch (ParseException | IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      }
	}
	
	public static String createInsertStudentLineForText(Student student) {
		String data = "";
		data = student.getStudentNumber()+";"+student.getStudentName()+";"+ formatter.format(student.getRegisteredDate())+";NO"+ "\n";
		return data;
	}
	
	public static String createInsertBookLineForText(Book book) {
		String data = "";
		String isBookInLibrary = "NO";
		if(book.getBookInLibrary()) {
			isBookInLibrary = "YES";
		}
		data = book.getBookName()+";"+book.getAuthorName()+";"+formatter.format(book.getInsertedDate())+";"+isBookInLibrary;
		if(book.getBorrowedDate() != null) {
		   data += ";" + formatter.format(book.getBorrowedDate());
		}else {
		   data += ";";
		}
		if (book.getLastBorrowedStudentNumber() != null) {
			data += ";" + book.getLastBorrowedStudentNumber();
		} else {
			data += ";";
		}
		if (book.getWillReturnDate() != null) {
			data += ";" + formatter.format(book.getWillReturnDate());
		} 
		return data;
	}
	
	public static void listBooks() {
		int i = 1;
		for(Book b : bookList) {
			if(b.getBookInLibrary()) {
				System.out.println(i + "--> Book: " + b.getBookName());
				i++;
			}
			
		}
	}
	
	public static Boolean controlStudentNumber(String studentNumber) {
		for(Student s :studentList) {
			if(s.getStudentNumber().equals(studentNumber)) {
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}
	
	public static void reserveBook(String bookName, String studentNumber, String returnDate) throws ParseException {
		deleteFile(bookFile);
		for(Book b : bookList) {
			if(b.getBookName().equals(bookName)) {
				b.setBookInLibrary(Boolean.FALSE);
				b.setBorrowedDate(new Date());
				b.setLastBorrowedStudentNumber(studentNumber);
				b.setWillReturnDate(formatter.parse(returnDate));
			}
			writeFile("insertBook",createInsertBookLineForText(b));
		}
		
		System.out.println(bookName + " reserved successfully!! HAVE A NICE DAY :) ");
	}
	
	public static void unreserveBook(String bookName, String studentNumber) throws ParseException {
		deleteFile(bookFile);
		for(Book b : bookList) {
			if(b.getBookName().equals(bookName)) {
				b.setBookInLibrary(Boolean.TRUE);
				b.setLastBorrowedStudentNumber(studentNumber);
				b.setWillReturnDate(new Date());
			}
			writeFile("insertBook",createInsertBookLineForText(b));
		}
		
		System.out.println(bookName + " is unreserved successfully!! Get a new book and get lots of new adventures :) ");
	}
	
	public static void deleteFile(String fileName) {
		File myObj = new File(fileName);
		if (myObj.delete()) {
			return;
		} else {
			System.out.println("Failed to delete the file.");
			return;
		}
	}
	
	public static void showOverdueBooks() {
		for(Book b: bookList) {
			if(!b.getBookInLibrary() && b.getWillReturnDate().compareTo(new Date()) < 0) {
			       long difference = new Date().getTime() - b.getWillReturnDate().getTime();
			       float daysBetween = (difference / (1000*60*60*24));
				System.out.println("Book Name: " + b.getBookName() +" Due Date Count: " + daysBetween);
			}
		}
	}
	
	public static String getDataFromUser() {
		Scanner s = new Scanner(System.in);
		String data = s.nextLine();
		return data;
	}
	
	public static int getIntFromUser() {
		Scanner s = new Scanner(System.in);
		int data = s.nextInt();
		return data;
	}
	
	public static Boolean studentsBorrowedBooks(String studentNumber) {
		int i = 1;
		Boolean hasBook = Boolean.TRUE;
		for(Book b : bookList) {
			if(!b.getBookInLibrary() && b.getLastBorrowedStudentNumber()!= null && b.getLastBorrowedStudentNumber().equals(studentNumber)) {
				System.out.println(i + "--> Book: " + b.getBookName());
				i++;
			}
		}
		
		if(i == 1) {
			System.out.println("You don't have reserved book!!!");
			hasBook = Boolean.FALSE;
		}
		
		return hasBook;
	}

}
